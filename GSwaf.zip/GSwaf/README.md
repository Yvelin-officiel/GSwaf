# GSwaf
Projet mobile java android




Fonctionnalités:

Random cocktail

profilage (catégorisation des préférences de l’user)

Listage et suggestion de boisson en fonction du profil

Liste d'ingrédients renvoie une liste de cocktails possible ou presque

Evaluation et comparaison de l’utilisateur (tier list)



========================

Search by ingredient
http://www.thecocktaildb.com/api/json/v1/1/filter.php?i=Gin
http://www.thecocktaildb.com/api/json/v1/1/filter.php?i=Vodka

Search by alcoholic?
http://www.thecocktaildb.com/api/json/v1/1/filter.php?a=Alcoholic
http://www.thecocktaildb.com/api/json/v1/1/filter.php?a=Non_Alcoholic

Filter by Category
http://www.thecocktaildb.com/api/json/v1/1/filter.php?c=Ordinary_Drink
http://www.thecocktaildb.com/api/json/v1/1/filter.php?c=Cocktail

Filter by Glass
http://www.thecocktaildb.com/api/json/v1/1/filter.php?g=Cocktail_glass
http://www.thecocktaildb.com/api/json/v1/1/filter.php?g=Champagne_flute

List the categories, glasses, ingredients or alcoholic filters
http://www.thecocktaildb.com/api/json/v1/1/list.php?c=list
http://www.thecocktaildb.com/api/json/v1/1/list.php?g=list
http://www.thecocktaildb.com/api/json/v1/1/list.php?i=list
http://www.thecocktaildb.com/api/json/v1/1/list.php?a=list



APIs
https://www.thecocktaildb.com/api.php





